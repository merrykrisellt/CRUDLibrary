package pe.edu.upeu.athenium;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtheniumApplicationTests {

	@Test
	void contextLoads() {
	}

}
