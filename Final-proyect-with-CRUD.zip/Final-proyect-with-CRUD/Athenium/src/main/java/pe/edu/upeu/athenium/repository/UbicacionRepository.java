package pe.edu.upeu.athenium.repository;


import pe.edu.upeu.athenium.model.Ubicacion;

public interface UbicacionRepository extends ICrudGenericoRepository<Ubicacion,Long>{
}
