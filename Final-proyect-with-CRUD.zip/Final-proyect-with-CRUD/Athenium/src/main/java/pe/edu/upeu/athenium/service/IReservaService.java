package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.Reserva;

public interface IReservaService extends ICrudGenericoService<Reserva, Integer> {
}
