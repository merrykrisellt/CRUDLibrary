package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Genero;

public interface GeneroRepository extends ICrudGenericoRepository <Genero,Long>{
}
