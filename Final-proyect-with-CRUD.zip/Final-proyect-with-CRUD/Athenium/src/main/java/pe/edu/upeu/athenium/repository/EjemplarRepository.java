package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Ejemplar;

public interface EjemplarRepository extends ICrudGenericoRepository<Ejemplar,Long> {
}
