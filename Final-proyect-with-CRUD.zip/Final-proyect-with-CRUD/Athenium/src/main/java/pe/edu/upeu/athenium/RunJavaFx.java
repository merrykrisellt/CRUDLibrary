package pe.edu.upeu.athenium;

public class RunJavaFx {
    public static void main(String[] args) {
        AtheniumApplication.main(args);
    }
}
